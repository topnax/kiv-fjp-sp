# Build instructions:
1. Run `cmake .`
2. Run `make`
3. The C-- compiler is now ready

# Compiler usage
`./CMM samples/basic.cmm` - compiles the `samples/basic.cmm` source code

# PL/0 interpreter usage
`./pmach out.pl0` - inteprets the compiled C-- program

Expected output:

```
$ ./pmach out.pl0
=== P-machine start ===
Hello world from C minus minus
Printing number 25: 25
TRUE!!!
=== P-machine stop ===
=== main() returned 15
```
