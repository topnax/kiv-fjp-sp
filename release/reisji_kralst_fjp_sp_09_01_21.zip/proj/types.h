// define possible types

#define TYPE_INT    1
#define TYPE_CHAR   2
#define TYPE_STRING 3
#define TYPE_BOOL   4
#define TYPE_META_STRUCT 5
#define TYPE_VOID 6

int convert_to_type_enum(char *in);
