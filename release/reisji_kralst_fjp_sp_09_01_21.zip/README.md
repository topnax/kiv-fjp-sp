# kiv-fjp-sp
`doc` folder contains the documentation of the project located in the `proj` folder.
`exec` folder contains compiled CMM compiler as well as PL/0 interpreter. 
